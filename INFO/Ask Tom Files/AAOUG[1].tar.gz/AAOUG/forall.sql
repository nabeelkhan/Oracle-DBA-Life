set echo on

@connect /

drop table emp;
create table emp as select * from scott.emp;
select empno, ename, sal from emp;
pause

declare
    type array is table of number;
    l_empnos   array;
    l_sals     array;
begin
    select empno, sal 
      bulk collect into l_empnos, l_sals
      from emp;
    for i in 1 .. l_empnos.count
    loop
        if ( l_sals(i) < 1000 )
        then
            l_empnos.delete(i);
        end if;
    end loop;
    forall i in INDICES OF l_empnos
        delete from emp where empno = l_empnos(i);
end;
/
pause

select empno, ename, sal from emp;
pause

delete from emp;
insert into emp select * from scott.emp;
commit;
pause

declare
    type array is table of number;
    type idx_array is table of binary_integer index by binary_integer;
    l_empnos   array;
    l_sals     array;
    l_update   idx_array;
    l_delete   idx_array;
begin
    select empno, sal 
      bulk collect into l_empnos, l_sals
      from emp;

    for i in 1 .. l_empnos.count
    loop
        if ( l_sals(i) < 1000 )
        then
            l_update(l_update.count) := i;
        else
            l_delete(l_delete.count) := i;
        end if;
    end loop;

    forall i in values of l_update
        update emp set sal = sal * 2 where empno = l_empnos(i);

    forall i in values of l_delete
        delete from emp where empno = l_empnos(i);
end;
/
pause

select empno, ename, sal from emp;
