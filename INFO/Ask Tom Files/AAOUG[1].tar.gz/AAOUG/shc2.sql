set echo on

create sequence iot_seq;

create or replace procedure produce_shc( p_time in number,
                                         p_trace in number default 0)
as
    type numType is table of
         number index by binary_integer;
    l_ips     numType;
	l_start   date := sysdate;
begin
    select distinct ip_address
      bulk collect into l_ips
      from ip_audit_tab_heap
	 order by dbms_random.value;

    if ( p_trace = 1 )
	then
		execute immediate q'|
            alter session set events 
			'10046 trace name context forever, level 12'
        |';
	end if;

	for j in 1 .. 9999999
    loop
		exit when (((sysdate-l_start)*24*60*60) > p_time);
        for i in 1 .. l_ips.count
        loop
			exit when (((sysdate-l_start)*24*60*60) > p_time);
            insert into ip_audit_tab_shc 
            ( ip_address, request_time, bytes, url )
            values
            ( l_ips(i), localtimestamp, 100, rpad('*', 80+mod(j,150), '*' ) );
            commit;
        end loop;
    end loop;
end;
/
show err

create or replace procedure produce_iot( p_time in number ,
                                         p_trace in number default 0)
as
    type numType is table of
         number index by binary_integer;
    l_ips     numType;
	l_start   date := sysdate;
begin
    select distinct ip_address
      bulk collect into l_ips
      from ip_audit_tab_heap
	 order by dbms_random.value;
    if ( p_trace = 1 )
	then
		execute immediate q'|
            alter session set events 
			'10046 trace name context forever, level 12'
        |';
	end if;

	for j in 1 .. 9999999
    loop
		exit when (((sysdate-l_start)*24*60*60) > p_time);
        for i in 1 .. l_ips.count
        loop
			exit when (((sysdate-l_start)*24*60*60) > p_time);
            insert into ip_audit_tab_iot 
            ( ip_address, request_time, seq, bytes, url )
            values
            ( l_ips(i), localtimestamp, iot_seq.nextval, 
			  100, rpad('*', 80+mod(j,150), '*' ) );
            commit;
        end loop;
    end loop;
end;
/
show err
pause

create or replace procedure consume_shc( p_time in number ,
                                         p_trace in number default 0)
as
    type numType is table of
         number index by binary_integer;
    l_ips     numType;

    cursor c is select rowid rid, a.* from ip_audit_tab_shc a;
    l_rec  c%rowtype;
	l_start   date := sysdate;

begin
    select distinct ip_address
      bulk collect into l_ips
      from ip_audit_tab_heap
	 order by dbms_random.value;
    if ( p_trace = 1 )
	then
		execute immediate q'|
            alter session set events 
			'10046 trace name context forever, level 12'
        |';
	end if;

    loop
		exit when (((sysdate-l_start)*24*60*60) > p_time);
        for i in 1 .. l_ips.count
        loop
		    exit when (((sysdate-l_start)*24*60*60) > p_time);
            begin
                select rowid, a.*
                  into l_rec
                  from ( select *  
                           from ip_audit_tab_shc
                          where ip_address = l_ips(i)
                          order by request_time
                        ) a
                  where rownum = 1;

                delete from ip_audit_tab_shc
                 where rowid = l_rec.rid;

                commit;
            exception
                when no_data_found then null;
            end;
        end loop;
    end loop;
end;
/
create or replace procedure consume_iot( p_time in number ,
                                         p_trace in number default 0)
as
    type numType is table of
         number index by binary_integer;
    l_ips     numType;

    cursor c is select rowid rid, a.* from ip_audit_tab_iot a;
    l_rec  c%rowtype;
	l_start   date := sysdate;

begin
    select distinct ip_address
      bulk collect into l_ips
      from ip_audit_tab_heap
	 order by dbms_random.value;
    if ( p_trace = 1 )
	then
		execute immediate q'|
            alter session set events 
			'10046 trace name context forever, level 12'
        |';
	end if;

    loop
		exit when (((sysdate-l_start)*24*60*60) > p_time);
        for i in 1 .. l_ips.count
        loop
		    exit when (((sysdate-l_start)*24*60*60) > p_time);
            begin
                select rowid, a.*
                  into l_rec
                  from ( select *  
                           from ip_audit_tab_iot
                          where ip_address = l_ips(i)
                          order by request_time
                        ) a
                  where rownum = 1;

                delete from ip_audit_tab_iot
                 where rowid = l_rec.rid;

                commit;
            exception
                when no_data_found then null;
            end;
        end loop;
    end loop;
end;
/
pause

create or replace procedure simulation
( p_procedure    in varchar2, p_time in number, p_trace in number := 0)
authid current_user
as
    l_job number;
    l_cnt number;
	l_parms varchar2(25) := '(' || p_time || ',' || p_trace || ');';

begin
    dbms_job.submit( l_job, 'consume_' || p_procedure || l_parms );
    dbms_job.submit( l_job, 'produce_' || p_procedure || l_parms );

    statspack.snap;
    commit;
    loop
        dbms_lock.sleep(3);
        select count(*) into l_cnt 
          from user_jobs 
         where what like 'consume%' 
            or what like 'produce%';
        exit when (l_cnt = 0);
    end loop;
    statspack.snap;
end;
/
