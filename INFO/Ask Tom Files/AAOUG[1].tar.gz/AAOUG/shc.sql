@connect /
set echo on

spool x
drop table ip_audit_tab_shc;
drop cluster shc;
drop TABLE ip_audit_tab_iot ;
drop TABLE ip_audit_tab_heap ;

CREATE CLUSTER shc 
( 
   ip_address    NUMBER, 
   request_time  timestamp SORT
)
HASHKEYS 1000 
HASH IS ip_address 
SIZE  20480
/

CREATE TABLE ip_audit_tab_shc 
(  ip_address    number,
   request_time  timestamp SORT,
   bytes         number,
   url           varchar2(255)
)
CLUSTER shc ( ip_address, request_time )
/


CREATE TABLE ip_audit_tab_iot 
(  ip_address    number,
   request_time  timestamp,
   seq           number,
   bytes         number,
   url           varchar2(255),
   primary key(ip_address,request_time,seq)
)
organization index
/

CREATE TABLE ip_audit_tab_heap 
(  ip_address    number,
   request_time  timestamp,
   bytes         number,
   url           varchar2(255) 
)
/
create index ip_audit_tab_heap_idx on 
ip_audit_tab_heap(ip_address,request_time);


REM select 123456780001 + trunc(rownum/180),
REM        sysdate-100+rownum/24/60, 
REM        object_id, 
REM        rpad( '*', 80+mod(rownum,150), '*' ) url
REM   from all_objects
REM / 


REM select 123456780001 + mod(rownum,255),
REM        sysdate-100+rownum/24/60, 
REM        object_id, 
REM        rpad( '*', 80+mod(rownum,150), '*' ) url
REM   from all_objects
REM / 

REM select 123456780001 + mod(rownum,255) ip,
REM        sysdate-100-rownum/24/60 dt, 
REM        object_id bytes, 
REM        rpad( '*', 80+mod(rownum,150), '*' ) url
REM   from all_objects
REM / 

insert into ip_audit_tab_shc 
( ip_address, request_time, bytes, url )
select 123456780001 + trunc(rownum/180),
       sysdate-100+rownum/24/60, 
       object_id, 
       rpad( '*', 80+mod(rownum,150), '*' ) url
  from all_objects
/ 

insert into ip_audit_tab_iot 
( ip_address, request_time, seq, bytes, url )
select 123456780001 + trunc(rownum/180),
       sysdate-100+rownum/24/60, 
	   rownum,
       object_id, 
       rpad( '*', 80+mod(rownum,150), '*' ) url
  from all_objects
/ 

insert into ip_audit_tab_heap
( ip_address, request_time, bytes, url )
select 123456780001 + trunc(rownum/180),
       sysdate-100+rownum/24/60, 
       object_id, 
       rpad( '*', 80+mod(rownum,150), '*' ) url
  from all_objects
/ 

analyze table ip_audit_tab_shc 
compute statistics 
for table;
analyze table ip_audit_tab_iot 
compute statistics 
for table 
for all indexes 
for all indexed columns;
analyze table ip_audit_tab_heap 
compute statistics 
for table 
for all indexes 
for all indexed columns;


variable x number
set autotrace traceonly explain
select * 
  from ip_audit_tab_shc
 where ip_address = :x
 order by request_time
/
select * 
  from (
select * 
  from ip_audit_tab_shc
 where ip_address = :x
 order by request_time
       )
 where rownum = 1
/
select * 
  from ip_audit_tab_shc
 where ip_address = :x
 order by bytes
/
set autotrace off
*/

@trace
declare
    type tableType is table of 
         ip_audit_tab_shc%rowtype index by binary_integer;
    l_recs tableType;

    type numType is table of 
         number index by binary_integer;
    l_ips  numType;
begin
    select distinct ip_address 
      bulk collect into l_ips
      from ip_audit_tab_heap;

    for i in 1..l_ips.count
    loop
        select ip_address, request_time, bytes, url 
          bulk collect into l_recs
          from ip_audit_tab_shc
         where ip_address = l_ips(i)
         order by request_time;

        select ip_address, request_time, bytes, url 
          bulk collect into l_recs
          from ip_audit_tab_iot
         where ip_address = l_ips(i)
         order by request_time;

        select ip_address, request_time, bytes, url 
          bulk collect into l_recs
          from ip_audit_tab_heap
         where ip_address = l_ips(i)
         order by request_time;
    end loop;
end;
/

spool off
