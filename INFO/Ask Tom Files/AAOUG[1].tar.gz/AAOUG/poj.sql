set echo on

@connect /
drop table time;

drop table inventory;

create table inventory
as
select product, dt, sum(quant) quant, rpad( 'x', 80, 'x' ) data
  from (
select 'product_' || (mod(rownum,100)+1) product, 
       trunc(sysdate)-trunc(dbms_random.value(0,200)) dt,
	   object_id quant
  from all_objects
       )
 group by product, dt
/

pause

alter table inventory add constraint inv_pk primary key(product,dt)
/

analyze table inventory compute statistics for table for all indexes
/

pause

select count(*) from inventory
/

delete from inventory 
 where product = 'product_1'
   and dt = trunc(sysdate)-5
/
commit;

create table time 
as
select trunc(sysdate)-(rownum-1)  dt
  from (select 1 
          from dual
		 group by cube(1,2,3,4) )
 where rownum <= 14;
analyze table time compute statistics;
pause


select time.dt, i.product, i.quant 
  from (select * from inventory where product = 'product_1' ) i 
       right outer join time on (time.dt=i.dt)
 order by product, time.dt
/
pause

select time.dt, i.product, i.quant 
  from (select * from inventory where product in ('product_1','product_2') ) i 
       right outer join time on (time.dt=i.dt)
 order by product, time.dt
/
pause

with
PRODUCTS
as
(select distinct product
   from inventory 
  where product in ('product_1','product_2') )
select time.dt, time.product, i.quant 
  from (select * from inventory where product in ('product_1','product_2') ) i 
       right outer join (select * from time,products) time on (time.dt=i.dt and time.product=i.product)
 order by time.product, time.dt
/
pause


select time.dt, i.product, i.quant
  from (select * from inventory where product in ('product_1','product_2') ) i  PARTITION BY (Product)
       right outer join TIME on ( time.dt = i.dt )
 order by product, time.dt
/
pause

select time.dt, i.product, i.quant,
       lag(i.quant) over (partition by i.product order by time.dt) last_quant
  from (select * from inventory where product in ('product_1','product_2') ) i  PARTITION BY (Product)
       right outer join TIME on ( time.dt = i.dt )
 order by product, time.dt
/
pause

delete from time;
insert into time
select trunc(sysdate)-(rownum-1)  dt
  from (select 1 
          from dual
		 group by cube(1,2,3,4,5,6,7,8) )
/
analyze table time compute statistics;
pause

set autotrace traceonly 
@trace
with 
PRODUCTS
as
(select distinct product
   from inventory  )
select time.dt, time.product, i.quant ,
       lag(i.quant) over (partition by i.product order by time.dt) last_quant
  from inventory i
       right outer join (select * from time,products) time on (time.dt=i.dt and time.product=i.product)
 order by time.product, time.dt
/
pause


select time.dt, i.product, i.quant,
       lag(i.quant) over (partition by i.product order by time.dt) last_quant
  from inventory i  PARTITION BY (Product)
       right outer join TIME on ( time.dt = i.dt )
 order by product, time.dt
/
set autotrace off
pause
@connect /
!tk
