@connect /
set echo on
drop table t;

clear screen
CREATE TABLE t ( dt date, data char(255))
PARTITION BY RANGE (dt) 
( PARTITION part1 VALUES LESS THAN (to_date('13-mar-2003','dd-mon-yyyy')) ,
  PARTITION part2 VALUES LESS THAN (to_date('14-mar-2003','dd-mon-yyyy')) ,
  PARTITION junk VALUES LESS THAN (MAXVALUE) );
create index t_idx on t(data) local;
pause

clear screen
insert into t ( dt, data )
select to_date('12-mar-2003')+mod(rownum,3), rownum
  from all_objects
 where rownum < 5
/
pause

clear screen
alter table t modify partition part2 compress
/
alter table t move partition part2
/
pause

clear screen
select partition_name, status
  from user_ind_partitions
 where index_name = 'T_IDX'
/
pause

clear screen
alter index t_idx rebuild partition part2
/
select partition_name, status
  from user_ind_partitions
 where index_name = 'T_IDX'
/
pause

clear screen
alter table t move partition part2 update indexes
/
select partition_name, status
  from user_ind_partitions
 where index_name = 'T_IDX'
/

