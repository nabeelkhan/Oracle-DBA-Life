
column platform_name format a30
select * from v$transportable_platform order by 1;
