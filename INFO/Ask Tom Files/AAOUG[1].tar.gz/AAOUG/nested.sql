declare
   type Colors is table of varchar2(64);
   primaries Colors := Colors('Blue','Green','Red');
   rgb Colors := Colors('Red','Green','Blue');
   traffic_light Colors := Colors('Red','Green','Amber');
begin
   IF primaries = rgb 
   THEN
      dbms_output.put_line('OK, PRIMARIES and RGB have the same members.');
   END IF;
   IF rgb != traffic_light 
   THEN
      dbms_output.put_line('OK, RGB and TRAFFIC_LIGHT have different members.');
   END IF;
end;
/
pause

DECLARE
  TYPE nested_typ IS TABLE OF NUMBER;
  nt1 nested_typ := nested_typ(1,2,3);
  nt2 nested_typ := nested_typ(3,2,1);
  nt3 nested_typ := nested_typ(2,3,1,3);
  nt4 nested_typ := nested_typ(1,2,4);

  PROCEDURE p( l_bool in boolean, l_msg in varchar2 )
  is
  begin
  	dbms_output.put_line
	( case when l_bool then 'True: ' else 'False: ' end || l_msg );
  END;
BEGIN
	p( (nt1 IN (nt2,nt3,nt4)), 'nt1 in (nt2,nt3,nt4)' );
	p( (nt1 SUBMULTISET OF nt3), 'nt1 SUBMULTISET OF nt3' );
	p( (nt1 NOT SUBMULTISET OF nt4 ), 'nt1 NOT SUBMULTISET OF nt4' );

	p( null, 'Cardinality of nt3 = ' || CARDINALITY(nt3) );
	p( null, 'Distinct Cardinality of nt3 = ' || CARDINALITY(SET(nt3)) );

	p( ( 4 MEMBER OF nt1 ), '4 member of nt1' );
	p( ( nt3 is a set ) , 'nt3 is a set' );
	p( ( nt3 IS NOT A SET ), 'nt3 is not a set' );
	p( ( nt1 is empty ), 'nt1 is empty' );
END;
/
