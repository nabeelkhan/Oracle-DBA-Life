set echo off
set termout off
@runstats
exec runstats_pkg.rs_start
exec runstats_pkg.rs_middle
exec runstats_pkg.rs_stop(900)
set termout on
set echo on


drop table t;
create table t ( x int );
clear screen

create or replace procedure proc1
as
begin
	for i in 1 .. 10000
	loop
		execute immediate 'insert into t values ( :x )' using i;
	end loop;
end;
/
create or replace procedure proc2
as
begin
	for i in 1 .. 10000
	loop
		execute immediate 'insert into t values ( '||i||')';
	end loop;
end;
/
pause

exec runstats_pkg.rs_start
exec proc1
exec runstats_pkg.rs_middle
exec proc2
exec runstats_pkg.rs_stop(900)
