@connect /
set echo on
set linesize 121
clear screen
select count(*), to_char(sum(sharable_mem),'999,999,999') sm
  from v$sql
 where sql_text like 'select /* nobind */ * from t where x = %';

select count(*), to_char(sum(sharable_mem),'999,999,999') sm
  from v$sql
 where sql_text = 'select /* bind */ * from t where x = :x';
pause

clear screen
declare
	l_stmt long := 'select /*+ RULE */ * from t where x in ( 1';
	l_rec  t%rowtype;
	l_cursor sys_refcursor;
begin
	for i in 2 .. 1000
	loop
		l_stmt := l_stmt || ', ' || i;
	end loop;
	l_stmt := l_stmt || ' ) or x in ( 1';
	for i in 1002 .. 2000
	loop
		l_stmt := l_stmt || ', ' || i;
	end loop;
	open l_cursor for l_stmt || ' )';
	fetch l_cursor into l_rec;
	close l_cursor;
end;
/
pause

clear screen
select count(*), to_char(sum(sharable_mem),'999,999,999') sm
  from v$sql
 where sql_text like 'select /*+ RULE */ * from t where x in ( 1%';
