//-- otn_tools.js: Core JS library for www.otn.oracle.com


//rotating banner script

var banner_images = new Array()
var banner_links = new Array()
var banner_target = new Array()

//
// to set up an image for banner rotation
// put image into /images/banners/
// modify array below to match
//	banner_images[n] = "image name"
//	banner_links[n] = "link URL"
//
// insert the following into the HTML
//	<script language="JavaScript">insertBanner()</script>
//

banner_images[0] = "banner_a1.gif"
banner_links[0] = "http://www.oracle.com/go/?&Src=134744&Act=55"
banner_target[0] = "_top"

banner_images[1] = "ovn_free_468x60.gif"
banner_links[1] = "http://www.oracle.com/go/?&Src=561636&Act=9"
banner_target[1] = "_top"

banner_images[2] = "468x60_stopbuy.gif"
banner_links[2] = "http://www.oracle.com/go/?&Src=257989&Act=8"
banner_target[2] = "_top"

banner_images[3] = "banner_a1.gif"
banner_links[3] = "http://www.oracle.com/go/?&Src=134744&Act=55"
banner_target[3] = "_top"

banner_images[4] = "ovn_free_468x60.gif"
banner_links[4] = "http://www.oracle.com/go/?&Src=561636&Act=9"
banner_target[4] = "_top"

banner_images[5] = "banner_a1.gif"
banner_links[5] = "http://www.oracle.com/go/?&Src=134744&Act=55"
banner_target[5] = "_top"

banner_images[6] = "468x60_stopbuy.gif"
banner_links[6] = "http://www.oracle.com/go/?&Src=257989&Act=8"
banner_target[6] = "_top"

banner_images[7] = "ovn_free_468x60.gif"
banner_links[7] = "http://www.oracle.com/go/?&Src=561636&Act=9"
banner_target[7] = "_top"

banner_images[8] = "banner_a1.gif"
banner_links[8] = "http://www.oracle.com/go/?&Src=134744&Act=55"
banner_target[8] = "_top"

banner_images[9] = "468x60_stopbuy.gif"
banner_links[9] = "http://www.oracle.com/go/?&Src=257989&Act=8"
banner_target[9] = "_top"


// insertBanner function, called by page
var number = String(Math.random()).charAt(8)
function insertBanner() {

	document.write("<a href='" + banner_links[number] + "' target='" + banner_target[number] + "'><img src='/images/banners/" + banner_images[number] + "' width='468' height='60' border='0'></a>")

}


//feedback poll script

 function submitForm()
 {
  var chkFlag = false;
  var len = document.poll.answer.length;

  for(var i=0; i<len; i++) {

   if(document.poll.answer[i].checked) {
    chkFlag = true;
    break;
   }
  }
  if(chkFlag == false) {


   alert("Please Choose an Answer before Submitting");
   return;
  }

  var newWindow = window.open( "" , "QPResult",
"width=450,height=300,scrollbars=yes,resizable=no,menubar=no,location=no");

        newWindow.focus();
        document.poll.action =
"http://www.oracle.com/webapps/quickpoll/RecordPoll.jsp";

        document.poll.target = "QPResult";
  document.poll.submit();
 }
