set echo on
set linesize 121
drop table t;

clear screen
create table t 
( x varchar2(10) primary key, 
  y date 
);
insert into t select rownum, created from all_users;
exec dbms_stats.gather_table_stats( user, 'T', cascade=>TRUE );
pause

delete from plan_table;
commit;
clear screen
variable n number
explain plan for select * from t where x = :n;
pause

clear screen
select * from table(dbms_xplan.display);
pause

set termout off
@?/rdbms/admin/utlxplan
set termout on
clear screen
exec :n := 1;
@trace
select * from t where x = :n;
pause
delete from plan_table;
commit;

clear screen
disconnect
connect /
!tkprof `ls -t $ORACLE_HOME/admin/$ORACLE_SID/udump/*ora_*.trc | head -1` ./tk.prf sys=no aggregate=no explain=/ 'table=ops$tkyte.plan_table'
edit tk.prf


delete from plan_table;
commit;
clear screen
variable n number
explain plan for select * from t where x = TO_NUMBER(:n);
pause

clear screen
select * from table(dbms_xplan.display);
pause

delete from plan_table;
commit;
clear screen
explain plan for select * from t where x = 1;
pause

clear screen
select * from table(dbms_xplan.display);
pause
