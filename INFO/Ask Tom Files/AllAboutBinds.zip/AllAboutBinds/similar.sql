disconnect
@connect /
set echo on
set linesize 121

drop table emp;
alter system flush shared_pool;

clear screen
create table emp as select * from scott.emp;
update emp set deptno = 99;
begin
	for i in 1 .. 11
	loop
		insert /*+ append */ into emp select * from emp;
		commit;
	end loop;
end;
/
select count(*) from emp;
pause

clear screen
update emp set deptno =  1 where rownum = 1;

create index dept_idx on emp(deptno);

begin
	dbms_stats.gather_table_stats
	( user, 'EMP', 
	  method_opt=>'for all indexed columns', 
	  cascade=>true );
end;
/
pause

clear screen
set autotrace traceonly explain
select * from emp where deptno = 99;
select * from emp where deptno = 1;
set autotrace off
pause

clear screen
@trace
alter session set cursor_sharing=similar;
set autotrace traceonly statistics
pause

clear screen
select * from emp CSS where deptno = 1;
pause

clear screen
select * from emp CSS where deptno = 99;
set autotrace off
pause

select * from dual;
disconnect 
connect /
!vitrc


set echo on
set linesize 121

clear screen
alter session set cursor_sharing=exact;
select sql_text from v$sql
 where sql_text like 'select * from emp CSS where deptno =%';
pause

drop table emp;
alter system flush shared_pool;

clear screen
create table emp as select * from scott.emp;
update emp set deptno = 99;
begin
	for i in 1 .. 11
	loop
		insert /*+ append */ into emp select * from emp;
		commit;
	end loop;
end;
/
select count(*) from emp;
pause

clear screen
update emp set deptno =  1 where rownum = 1;

create index dept_idx on emp(deptno);

begin
	dbms_stats.gather_table_stats
	( user, 'EMP', 
	  cascade=>true );
end;
/
pause


clear screen
set autotrace traceonly explain
select * from emp new_stats where deptno = 99;
select * from emp new_stats where deptno = 1;
set autotrace off
pause

clear screen
alter session set cursor_sharing=similar;
set autotrace traceonly statistics
pause

clear screen
select * from emp CSS2 where deptno = 1;
pause

clear screen
select * from emp CSS2 where deptno = 99;
set autotrace off
alter session set cursor_sharing=exact;
pause

clear screen
select sql_text from v$sql
 where sql_text like 'select * from emp CSS2 where deptno =%';



