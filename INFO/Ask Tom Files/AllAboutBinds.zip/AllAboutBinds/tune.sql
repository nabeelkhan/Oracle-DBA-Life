set echo on
set linesize 121

drop table t;
alter system flush shared_pool;

clear screen
create table t
as
select 99 id, a.* from all_objects a;
update t set id = 1 where rownum = 1;
create index t_idx on t(id);
pause

clear screen
begin
	dbms_stats.gather_table_stats
	( user, 'T', 
	  method_opt => 'for all indexed columns size 254', 
	  cascade=> true); 
end;
/
pause

set echo off
set termout off
variable n number
exec :n := 99
set autotrace traceonly statistics
select * from t where id = :n;
set autotrace off
set termout on
set echo on

clear screen
variable n number
exec :n := 99
set autotrace traceonly statistics
select * from t where id = :n;
set autotrace off
pause

clear screen
exec :n := 1
set autotrace traceonly statistics
select * from t where id = :n;
set autotrace off
pause

clear screen
set autotrace traceonly statistics
alter session set events '10046 trace name context forever, level 12';
select * from t where id = :n;
set autotrace off
pause

clear screen
set autotrace traceonly statistics
alter session set events '10046 trace name context off';
select * from t where id = :n;
set autotrace off
pause

clear screen
select parsing_user_id puid, parsing_schema_id psid,
       address, child_address
  from v$sql
 where sql_text = 'select * from t where id = :n';
