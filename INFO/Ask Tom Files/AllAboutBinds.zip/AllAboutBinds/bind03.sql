@connect /

drop table t;
set echo on

clear screen
create table t ( x int primary key );
pause

clear screen
create or replace procedure nobind
as
    l_cursor sys_refcursor;
begin
    for i in 1 .. 10000
    loop
        open l_cursor for 'select /* nobind */ * from t where x = ' || i;
        close l_cursor;
    end loop;
end;
/
pause

clear screen
create or replace procedure bind
as
    l_cursor sys_refcursor;
begin
    for i in 1 .. 10000
    loop
        open l_cursor for 'select /* bind */ * from t where x = :x' using i;
        close l_cursor;
    end loop;
end;
/
pause


clear screen
exec runstats_pkg.rs_start
exec nobind
exec runstats_pkg.rs_middle
exec bind
exec runstats_pkg.rs_stop(10000)
