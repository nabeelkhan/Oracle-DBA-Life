@connect /

drop table t;
drop table parse_stats;
set echo on

clear screen
create table t ( x int primary key );
create table parse_stats 
as
select a.name, b.value, cast( null as number ) run1, cast(null as number) run2
  from v$statname a, v$mystat b
 where a.statistic# = b.statistic#
   and a.name like 'parse%';
pause

clear screen
set timing on
declare
    l_cursor sys_refcursor;
begin
    for i in 1 .. 10000
    loop
        open l_cursor for 'select /* nobind */ * from t where x = ' || i;
        close l_cursor;
    end loop;
end;
/
merge into parse_stats using ( select a.name, b.value new_val
                                 from v$statname a, v$mystat b
                                where a.statistic# = b.statistic#
                                  and a.name like 'parse%' ) s
on (parse_stats.name = s.name) when matched then update set run1 = new_val;

pause

clear screen
declare
    l_cursor sys_refcursor;
begin
    for i in 1 .. 10000
    loop
        open l_cursor for 'select /* bind */ * from t where x = :x' using i;
        close l_cursor;
    end loop;
end;
/
merge into parse_stats using ( select a.name, b.value new_val
                                 from v$statname a, v$mystat b
                                where a.statistic# = b.statistic#
                                  and a.name like 'parse%' ) s
on (parse_stats.name = s.name) when matched then update set run2 = new_val;
pause

set timing off
clear screen
select name, run1, run2, 
       decode( run1, 0, null, 
               to_char(run2/run1*100,'9,999.00') || ' %' ) run2_pct_of_run1
  from (
select name, run1-value run1, run2-run1 run2
  from parse_stats
       )
/
