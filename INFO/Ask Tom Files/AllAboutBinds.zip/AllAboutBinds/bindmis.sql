set echo on
set linesize 121

drop table t;
alter system flush shared_pool;

clear screen
create table t ( x varchar2(2000) );
pause

clear screen
declare
        a   varchar2(1)    := 'x';
        b   varchar2(100)  := rpad('x',100,'x');
        c   varchar2(500)  := rpad('x',500,'x');
        d   varchar2(1000) := rpad('x',1000,'x');
begin
        insert into t values(a);
        insert into t values(b);
        insert into t values(c);
        insert into t values(d);
end;
/
pause

clear screen
column sql_text format a30
column address new_val ADDR
select parsing_user_id puid, parsing_schema_id psid,
       sql_text, address, child_address
  from v$sql
 where sql_text like 'INSERT%INTO%T%VALUES(%:B1%)'
/
pause

clear screen
select *
  from v$sql_shared_cursor
 where address = '&ADDR'
/
pause

clear screen
select bind_mismatch
  from v$sql_shared_cursor
 where address = '&ADDR'
/
pause
clear screen
declare
        a   varchar2(1) := 'x';
        b   varchar2(10) := rpad('x',10,'x');
        c   varchar2(20) := rpad('x',20,'x');
        d   varchar2(30) := rpad('x',30,'x');
begin
        insert into t xxx values(a);
        insert into t xxx values(b);
        insert into t xxx values(c);
        insert into t xxx values(d);
end;
/
pause

clear screen
select parsing_user_id puid, parsing_schema_id psid,
       sql_text, address, child_address
  from v$sql
 where sql_text like 'INSERT%INTO%T%VALUES(%:B1%)'
/
pause

clear screen
declare
        a   varchar2(1)    := 'x';
        b   varchar2(10)  := rpad('x',10,'x');
        c   varchar2(32)  := rpad('x',32,'x');
        d   varchar2(33) := rpad('x',33,'x');
begin
        insert into t yyy values(a);
        insert into t yyy values(b);
        insert into t yyy values(c);
        insert into t yyy values(d);
end;
/
pause

clear screen
select parsing_user_id puid, parsing_schema_id psid,
       sql_text, address, child_address
  from v$sql
 where sql_text like 'INSERT%INTO%T%VALUES(%:B1%)'
/
