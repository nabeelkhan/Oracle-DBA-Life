set echo on
set linesize 121

drop table t;
alter system flush shared_pool;

alter session set cursor_sharing=exact;
create table t 
as
select * 
  from all_users
 where rownum = 1;
pause

alter session set cursor_sharing=exact;
select substr(username,1,10) uname,
       to_char(user_id,'999,999') u_id,
       to_char(created,'Dy Mon DD, YYYY' ) created
  from t cs_exact;
pause

alter session set cursor_sharing=force;
select substr(username,1,10) uname,
       to_char(user_id,'999,999') u_id,
       to_char(created,'Dy Mon DD, YYYY' ) created
  from t cs_force;
pause
alter session set cursor_sharing=exact;
column sql_text format a80
select sql_text 
  from v$sql
 where sql_text like 'select substr(username%';
