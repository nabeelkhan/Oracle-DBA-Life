set echo on
define NumUsers=&1
define NumIters=&2

@connect /

drop table t;
create table t ( x int primary key );

drop table job_table;
create table job_table ( job number primary key, iters number ) organization index;

create or replace procedure do_sql( p_job in number )
as
    l_cursor sys_refcursor;
	l_rec    job_table%rowtype;
begin
	select * into l_rec from job_table where job = p_job;
    for i in 1 .. l_rec.iters
    loop
        open l_cursor for 'select * from t t' || p_job || ' where x = ' || i;
        close l_cursor;
    end loop;
	delete from job_table where job = p_job;
	commit;
end;
/

declare
	l_job	number;
begin
	for i in 1 .. &NumUsers
	loop
		dbms_job.submit( l_job, 'do_sql(job);' );
		insert into job_table values ( l_job, &NumIters );
	end loop;
	commit;
end;
/

exec statspack.snap
declare
	l_cnt number;
begin
	loop
		select count(*) into l_cnt from job_table where rownum=1;
		exit when l_cnt = 0;
		sys.dbms_lock.sleep(5);
	end loop;
end;
/
exec statspack.snap

column b new_val begin_snap
column e new_val end_snap
define report_name=multiuser_&NumUsers._&NumIters
select perfstat.stats$snapshot_id.nextval-2 b,
       perfstat.stats$snapshot_id.nextval-1 e
  from dual;

insert into perfstat.STATS$IDLE_EVENT ( event ) 
select 'PL/SQL lock timer' 
  from dual 
 where not exists 
 (select null from perfstat.STATS$IDLE_EVENT where event = 'PL/SQL lock timer')
/
commit;

@?/rdbms/admin/spreport
