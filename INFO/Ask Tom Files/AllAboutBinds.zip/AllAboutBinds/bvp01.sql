set echo on
set linesize 121
drop table t;

clear screen
create table t
as
select 99 id, a.* from all_objects a;

update t set id = 1 where rownum = 1;

create index t_idx on t(id);
pause

clear screen
begin
   dbms_stats.gather_table_stats
   ( user, 'T', 
     method_opt=>'for all indexed columns size 254', 
	 cascade=>TRUE );
end;
/
alter system flush shared_pool;
pause

clear screen
variable n number
exec :n := 1
delete from plan_table;
explain plan for 
select count(object_type) from t n_is_1_first where id = :n;
pause


clear screen
select * from table(dbms_xplan.display);
pause


clear screen
@trace
select count(object_type) from t n_is_1_first where id = :n;
pause
clear screen

exec :n := 99
@traceoff
delete from plan_table;
explain plan for 
select count(object_type) from t n_is_1_first where id = :n;
pause



clear screen
select * from table(dbms_xplan.display);
pause



clear screen
@trace
select count(object_type) from t n_is_1_first where id = :n;
pause



clear screen
exec :n := 99
@traceoff
delete from plan_table;
explain plan for 
select count(object_type) from t n_is_99_first where id = :n;
pause



clear screen
select * from table(dbms_xplan.display);
pause


clear screen
@trace
select count(object_type) from t n_is_99_first where id = :n;
pause
clear screen

exec :n := 1
@traceoff
delete from plan_table;
explain plan for 
select count(object_type) from t n_is_99_first where id = :n;
pause



clear screen
select * from table(dbms_xplan.display);
pause
clear screen
@trace
select count(object_type) from t n_is_99_first where id = :n;
pause

set termout off
@?/rdbms/admin/utlxplan
delete from plan_table;
commit;
set termout on
clear screen
disconnect
connect /
!tkprof `ls -t $ORACLE_HOME/admin/$ORACLE_SID/udump/*ora_*.trc | head -1` ./tk.prf sys=no aggregate=no explain=/ 'table=ops$tkyte.plan_table'
edit tk.prf

set echo off
clear screen
prompt so, how can you see the "true" plan that'll be used given bind variable peeking?
prompt
set echo on
@trace
declare
	l_99	number := 99;
	l_1 	number := 1;
	cursor c1 is select count(object_type) from t bind_was_99 where id = l_99;
	cursor c2 is select count(object_type) from t bind_was_1 where id = l_1;
begin
	open c1;
	open c2;
	close c1;
	close c2;
end;
/
pause
delete from plan_table;
commit;
disconnect
connect /
!tkprof `ls -t $ORACLE_HOME/admin/$ORACLE_SID/udump/*ora_*.trc | head -1` ./tk.prf sys=no aggregate=no explain=/ 'table=ops$tkyte.plan_table'
edit tk.prf

