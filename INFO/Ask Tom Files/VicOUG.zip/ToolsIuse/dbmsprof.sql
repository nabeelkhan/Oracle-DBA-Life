@connect /


/*
set termout off
@?/rdbms/admin/proftab
@profrep
set termout on
*/

@dbmsprof1
@dbmsprof2

