select count(*) from v$session_longops where time_remaining > 0;

begin
	print_table( 'select * from v$session_longops where time_remaining > 0');
end;
/
