@connect /

set echo on

clear screen
create or replace procedure test_proc( p_iters in number )
as
    l_number               number;
    l_number_constrained number(10);
    l_int                int;
    l_plsql_int          pls_integer;
    l_bin_int            binary_integer;
    l_float              float;
begin
    for i in 1 .. p_iters
    loop
        l_number             := i;
        l_number_constrained := i;
        l_int                := i;
        l_plsql_int          := i;
        l_bin_int            := i;
        l_float              := i;
    end loop;    
end;
/
pause
clear screen
exec dbms_profiler.start_profiler( 'number compares' )
exec test_proc(500000);
exec dbms_profiler.stop_profiler
@profsum 
set termout off
@profreset
set termout on
clear screen
set echo off
prompt
prompt
prompt You should try this in 9ir2 to see what a difference a version makes...
set echo on
