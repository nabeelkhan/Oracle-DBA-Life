@connect /

set termout off
@?/rdbms/admin/proftab
@?/plsql/demo/profrep
set termout on
set echo on


create or replace
function fact_recursive( n int ) return number
as
begin
        if ( n = 1 )
        then
                return 1;
        else
                return n * fact_recursive(n-1);
        end if;
end;
/
pause

create or replace
function fact_iterative( n int ) return number
as
        l_result number default 1;
begin
        for i in 2 .. n
        loop
                l_result := l_result * i;
        end loop;
        return l_result;
end;
/
pause

set serveroutput off

exec dbms_profiler.start_profiler( 'factorial recursive' )

begin
	for i in 1 .. 5000 loop
		dbms_output.put_line( fact_recursive(50) );
	end loop;
end;
/

exec dbms_profiler.stop_profiler

exec dbms_profiler.start_profiler( 'factorial iterative' )

begin
	for i in 1 .. 5000 loop
		dbms_output.put_line( fact_iterative(50) );
	end loop;
end;
/

exec dbms_profiler.stop_profiler
set serveroutput on size 1000000
pause

@profsum 


set termout off
@profreset
set termout on
set echo on

create or replace procedure test_proc( p_iters in number )
as
	l_number  	         number;
	l_number_constrained number(10);
	l_int                int;
	l_plsql_int          pls_integer;
	l_bin_int            binary_integer;
	l_float              float;
begin
	for i in 1 .. p_iters
	loop
		l_number  	         := i;
		l_number_constrained := i;
		l_int                := i;
		l_plsql_int          := i;
		l_bin_int            := i;
		l_float              := i;
	end loop;	
end;
/
exec dbms_profiler.start_profiler( 'number compares' )
exec test_proc(500000);
exec dbms_profiler.stop_profiler
@profsum 


