
set echo on
set linesize 121

/*
first, we'll look at autotrace and it's output for explain plans, comparing
the different effects of different analyzes
*/

drop table t;
create table t as select * from all_objects;
create index t_idx on t(object_id);

begin
	dbms_stats.gather_table_stats
	( user, 'T', 
	  method_opt=> 'for columns REPEAT', 
	  cascade => TRUE );
end;
/

set autotrace traceonly explain
select * from t where object_id = 55;
pause

begin
	dbms_stats.gather_table_stats
	( user, 'T', 
	  method_opt=> 'for all indexed columns size 254',
	  cascade => TRUE );
end;
/
select * from t where object_id = 55;
pause
set autotrace off

/*
Next we'll look at autotrace statistics -- showing in this case the effect
of arraysize on consistent gets (and hence latching for example)

start by looking at the number of blocks in T
*/

select blocks, num_rows/blocks from user_tables where table_name='T';
pause

set autotrace traceonly statistics
set arraysize 10
select * from t;
pause
set arraysize 100
select * from t;
pause
set arraysize 500
select * from t;
pause
set autotrace off

drop table emp;
drop table dept;
drop table bonus;
create table emp as select * from scott.emp;
create table dept as select * from scott.dept;
create table bonus as select * from scott.bonus;
alter table emp add constraint emp_pk primary key(empno);
alter table dept add constraint dept_pk primary key(deptno);
create index bonus_idx on bonus(ename);

exec dbms_stats.gather_table_stats( user, 'EMP', cascade=>true);
exec dbms_stats.gather_table_stats( user, 'DEPT', cascade=>true);
exec dbms_stats.gather_table_stats( user, 'BONUS', cascade=>true);
pause

delete from plan_table;

explain plan for
select *
  from emp, dept
 where emp.deptno = dept.deptno
   and not exists ( select null from bonus where ename = emp.ename );
pause

select plan_table_output 
  from table(dbms_xplan.display);
pause

delete from plan_table;
variable deptno varchar2(20) 
explain plan for 
select * 
  from dept 
 where deptno = :deptno;
pause
select plan_table_output 
  from table(dbms_xplan.display);


