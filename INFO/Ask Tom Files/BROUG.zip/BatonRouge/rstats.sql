@connect /

set termout off
@runstats
set termout on

set echo on

/* 
Bind variable comparision -- what happens when you DON'T use em 
*/
drop table t;
create table t ( x int, y char(80) );
pause

create or replace procedure p1
as
begin
    for i in 1 .. 5000
    loop
        execute immediate '
        insert into t (x,y) values ( :x, :y )' using i, i;
    end loop;
end;
/
create or replace procedure p2
as
begin
    for i in 1 .. 5000
    loop
        execute immediate '
        insert into t (x,y) values 
		( ' || i || ', ''' || replace(i,'''','''''') || ''' )';
    end loop;
end;
/

pause

exec runStats_pkg.rs_start
exec p1
exec runStats_pkg.rs_middle
exec p2
exec runStats_pkg.rs_stop(200)
