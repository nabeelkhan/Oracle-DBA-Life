-- ***************************************************************************
-- File: 12_53.sql
--
-- Developed By TUSC
--
-- Disclaimer: Neither Osborne/McGraw-Hill, TUSC, nor the author warrant
--             that this source code is error-free. If any errors are
--             found in this source code, please report them to TUSC at
--             (630)960-2909 ext 1011 or trezzoj@tusc.com.
-- ***************************************************************************

SPOOL 12_53.lis

SELECT product_id, product_name, LENGTH(product_name)
FROM   s_product
WHERE  INSTR(product_name, '2') > 0
ORDER BY product_id;

SPOOL OFF
