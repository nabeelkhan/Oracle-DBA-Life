-- ***************************************************************************
-- File: 6_44.sql
--
-- Developed By TUSC
--
-- Disclaimer: Neither Osborne/McGraw-Hill, TUSC, nor the author warrant
--             that this source code is error-free. If any errors are
--             found in this source code, please report them to TUSC at
--             (630)960-2909 ext 1011 or trezzoj@tusc.com.
-- ***************************************************************************

SPOOL 6_44.lis

DECLARE
   lv_test_num NUMBER := 9324.66;
BEGIN
   DBMS_OUTPUT.PUT_LINE(TO_CHAR(lv_test_num, '$999,999.99'));
END;
/

SPOOL OFF
