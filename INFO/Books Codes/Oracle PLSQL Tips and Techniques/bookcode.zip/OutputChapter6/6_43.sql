-- ***************************************************************************
-- File: 6_43.sql
--
-- Developed By TUSC
--
-- Disclaimer: Neither Osborne/McGraw-Hill, TUSC, nor the author warrant
--             that this source code is error-free. If any errors are
--             found in this source code, please report them to TUSC at
--             (630)960-2909 ext 1011 or trezzoj@tusc.com.
-- ***************************************************************************

SPOOL 6_43.lis

DECLARE
   lv_test_date DATE := SYSDATE;
   -- The separator_line procedure is called on each break of each 
   -- date function.
   PROCEDURE separator_line IS
   BEGIN
      DBMS_OUTPUT.PUT_LINE('-----------------------------------');
   END separator_line;
BEGIN
   separator_line;
   DBMS_OUTPUT.PUT_LINE(lv_test_date);
   separator_line;
   -- Shows the date and time, the date without the time, and the
   -- time on the West coast
   DBMS_OUTPUT.PUT_LINE(TO_CHAR(lv_test_date, 
      'DD-MON-YYYY HH24:MI:SS'));
   DBMS_OUTPUT.PUT_LINE(TO_CHAR(TRUNC(lv_test_date), 
      'DD-MON-YYYY HH24:MI:SS'));
   DBMS_OUTPUT.PUT_LINE(TO_CHAR(NEW_TIME(lv_test_date, 
      'CST', 'PST'), 'DD-MON-YYYY HH24:MI:SS'));
   separator_line;
   -- Dates can be modified to go forward or backward by integers,
   -- the last example returns the same date
   DBMS_OUTPUT.PUT_LINE(TO_CHAR(ADD_MONTHS(lv_test_date, 9), 
     'MM/DD/YYYY'));
   DBMS_OUTPUT.PUT_LINE(TO_CHAR(ADD_MONTHS(lv_test_date, -5), 
      'MM/DD/YYYY'));
   DBMS_OUTPUT.PUT_LINE(TO_CHAR(ADD_MONTHS(lv_test_date, .5), 
      'MM/DD/YYYY'));
   separator_line;
   -- Provides the last day of the month
   DBMS_OUTPUT.PUT_LINE(TO_CHAR(LAST_DAY(lv_test_date), 
      'MM/DD/YYYY'));
   separator_line;
   -- Returns the number of months between 2 dates entered, it
   -- returns a number (+ or -), and fraction if the dates are not
   -- the same day of the months being compared or if the dates 
   -- are not the last day of the each month
   DBMS_OUTPUT.PUT_LINE(MONTHS_BETWEEN(lv_test_date, 
      lv_test_date + 32));
   DBMS_OUTPUT.PUT_LINE(MONTHS_BETWEEN(LAST_DAY(lv_test_date+32),
      LAST_DAY(lv_test_date)));
   separator_line;
   -- Provides the date of the next occurrence of the day
   DBMS_OUTPUT.PUT_LINE(TO_CHAR(NEXT_DAY(lv_test_date, 'MON'), 
      'MM/DD/YYYY'));
   separator_line;
   -- Rounds the date to the specified precision, the first is by
   -- date, the second is the nearest year
   DBMS_OUTPUT.PUT_LINE(TO_CHAR(ROUND(lv_test_date), 
      'MM/DD/YYYY'));
   DBMS_OUTPUT.PUT_LINE(TO_CHAR(ROUND(lv_test_date, 'YYYY'), 
      'MM/DD/YYYY'));
   separator_line;
END;
/

SPOOL OFF
