-- ***************************************************************************
-- File: 6_45.sql
--
-- Developed By TUSC
--
-- Disclaimer: Neither Osborne/McGraw-Hill, TUSC, nor the author warrant
--             that this source code is error-free. If any errors are
--             found in this source code, please report them to TUSC at
--             (630)960-2909 ext 1011 or trezzoj@tusc.com.
-- ***************************************************************************

SPOOL 6_45.lis

DECLARE
   lv_test_date DATE := SYSDATE;
BEGIN
   DBMS_OUTPUT.PUT_LINE(lv_test_date);
   DBMS_OUTPUT.PUT_LINE(TO_CHAR(lv_test_date, 
      'MM/DD/YYYY: HH24:MI:SS'));
   DBMS_OUTPUT.PUT_LINE(TO_CHAR(lv_test_date, 'MM/DD/YYYY'));
   -- The Q preceding the YYYY will equate to the quarter the 
   -- date falls in
   DBMS_OUTPUT.PUT_LINE(TO_CHAR(lv_test_date, 'Q, YYYY')); 
   DBMS_OUTPUT.PUT_LINE(TO_CHAR(lv_test_date, 'YEAR'));
   -- The FM preceding the MONTH returns the actual length of the 
   -- month, without the FM, the month is padded out to 9 spaces.
   DBMS_OUTPUT.PUT_LINE(TO_CHAR(lv_test_date, 
      'FMMONTH DDTH, YYYY'));
   -- The SP on the end of the DD, specifies to spell out the 
   -- number.
   DBMS_OUTPUT.PUT_LINE(TO_CHAR(lv_test_date, 
      'FMMONTH DDSPTH, YEAR'));
END;
/

SPOOL OFF
