-- ***************************************************************************
-- File: 6_38.sql
--
-- Developed By TUSC
--
-- Disclaimer: Neither Osborne/McGraw-Hill, TUSC, nor the author warrant
--             that this source code is error-free. If any errors are
--             found in this source code, please report them to TUSC at
--             (630)960-2909 ext 1011 or trezzoj@tusc.com.
-- ***************************************************************************

SPOOL 6_38.lis

DECLARE
   CURSOR cur_employee IS
      SELECT employee_last_name || ', ' ||
             employee_first_name name,
             DECODE(commission_pct, NULL, 'NO',
                    0, 'NO', 'YES') comm_flag,
             salary
      FROM   s_employee
      ORDER BY DECODE(COMMISSION_PCT, NULL, 'NO',
                      0, 'NO', 'YES') DESC;
BEGIN
   FOR lv_cur_employee_rec IN cur_employee LOOP
      DBMS_OUTPUT.PUT_LINE('Employee: ' ||
         RPAD(lv_cur_employee_rec.name, 18, ' ')  || 
         'Commission?: ' || 
         LPAD(lv_cur_employee_rec.comm_flag, 3) ||
         CHR(9) || ' Salary: ' ||
         TO_CHAR(lv_cur_employee_rec.salary, '$999,999.99'));
   END LOOP;
END;
/

SPOOL OFF
