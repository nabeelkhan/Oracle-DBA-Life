-- ***************************************************************************
-- File: 6_39.sql
--
-- Developed By TUSC
--
-- Disclaimer: Neither Osborne/McGraw-Hill, TUSC, nor the author warrant
--             that this source code is error-free. If any errors are
--             found in this source code, please report them to TUSC at
--             (630)960-2909 ext 1011 or trezzoj@tusc.com.
-- ***************************************************************************

SPOOL 6_39.lis

DECLARE
   lv_test_txt VARCHAR2(80);
   lv_test_num PLS_INTEGER;
BEGIN
   lv_test_txt := LPAD('&&input_value',
      (&&length_of_column - LENGTH('&&input_value'))/2 +
      LENGTH('&&input_value'), '&&value_to_pad');
   lv_test_num := LENGTH(lv_test_txt);
   DBMS_OUTPUT.PUT_LINE(lv_test_txt);
   DBMS_OUTPUT.PUT_LINE(lv_test_num);
END;
/

SPOOL OFF
