-- ***************************************************************************
-- File: 6_41.sql
--
-- Developed By TUSC
--
-- Disclaimer: Neither Osborne/McGraw-Hill, TUSC, nor the author warrant
--             that this source code is error-free. If any errors are
--             found in this source code, please report them to TUSC at
--             (630)960-2909 ext 1011 or trezzoj@tusc.com.
-- ***************************************************************************

SPOOL 6_41.lis

DECLARE
   lv_temp_txt VARCHAR2(20);
BEGIN
   lv_temp_txt := UPPER('&input_value');
   DBMS_OUTPUT.PUT_LINE('Original Value: ' ||
      lv_temp_txt);
   lv_temp_txt := REPLACE(lv_temp_txt, UPPER('&value_to_replace'),
      UPPER('&replacement_value'));
   DBMS_OUTPUT.PUT_LINE('Replaced Value: ' ||
      lv_temp_txt);
END;
/

SPOOL OFF
