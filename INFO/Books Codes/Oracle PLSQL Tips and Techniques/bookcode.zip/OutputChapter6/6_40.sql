-- ***************************************************************************
-- File: 6_40.sql
--
-- Developed By TUSC
--
-- Disclaimer: Neither Osborne/McGraw-Hill, TUSC, nor the author warrant
--             that this source code is error-free. If any errors are
--             found in this source code, please report them to TUSC at
--             (630)960-2909 ext 1011 or trezzoj@tusc.com.
-- ***************************************************************************

SPOOL 6_40.lis

DECLARE
   lv_input_filename_txt VARCHAR2(40):= '\nightly\batch\main.dat';
   lv_log_filename_txt   VARCHAR2(40):= 
      SUBSTR(lv_input_filename_txt,1, INSTR(lv_input_filename_txt,
      '.') - 1) || '.log';
   lv_input_column_txt   VARCHAR2(20):= '   RECORD1   ';
   lv_final_column_txt   VARCHAR2(20):= 
      LTRIM(RTRIM(lv_input_column_txt, ' '));
   lv_input_length_num   PLS_INTEGER;
   lv_final_length_num   PLS_INTEGER;
BEGIN
   DBMS_OUTPUT.PUT_LINE('Input Filename:      ' || 
      lv_input_filename_txt);
   DBMS_OUTPUT.PUT_LINE('Log Filename:        ' || 
      lv_log_filename_txt);
   DBMS_OUTPUT.PUT_LINE('Input Column Value:  ' || 
      lv_input_column_txt);
   DBMS_OUTPUT.PUT_LINE('Final Column Value:  ' || 
      lv_final_column_txt);
   lv_input_length_num := LENGTH(lv_input_column_txt);
   lv_final_length_num := LENGTH(lv_final_column_txt);
   DBMS_OUTPUT.PUT_LINE('Input Column Length: ' || 
      lv_input_length_num);
   DBMS_OUTPUT.PUT_LINE('Final Column Length: ' || 
      lv_final_length_num);
END;
/

SPOOL OFF
