-- ***************************************************************************
-- File: 6_22.sql
--
-- Developed By TUSC
--
-- Disclaimer: Neither Osborne/McGraw-Hill, TUSC, nor the author warrant
--             that this source code is error-free. If any errors are
--             found in this source code, please report them to TUSC at
--             (630)960-2909 ext 1011 or trezzoj@tusc.com.
-- ***************************************************************************

SPOOL 6_22.lis

BEGIN
   -- The single line comment can be used in a literal text string
   -- without any special coding to identify the usage as literal
   -- text versus the start of a comment.
   DBMS_OUTPUT.PUT_LINE
      ('This illustrates the use of a literal --');
   /* The multiple line comment can also be used in a literal text
      string without any special coding to identify the usage as
      literal text versus the start or end of a comment. */
   DBMS_OUTPUT.PUT_LINE
      ('This illustrates the use of a literal /* */');
END;
/

SPOOL OFF
