-- ***************************************************************************
-- File: 6_42.sql
--
-- Developed By TUSC
--
-- Disclaimer: Neither Osborne/McGraw-Hill, TUSC, nor the author warrant
--             that this source code is error-free. If any errors are
--             found in this source code, please report them to TUSC at
--             (630)960-2909 ext 1011 or trezzoj@tusc.com.
-- ***************************************************************************

SPOOL 6_42.lis

DECLARE
   lv_temp_txt VARCHAR2(20);
BEGIN
    lv_temp_txt := '&input_value';
   DBMS_OUTPUT.PUT_LINE('Original Value: ' ||
      lv_temp_txt);
   -- Every 0 is replaced by a 9, every 1 is replaced by a 9,
   -- every 2 is replaced by a 9 and so forth
   lv_temp_txt := TRANSLATE(lv_temp_txt,'012345678','999999999');
   DBMS_OUTPUT.PUT_LINE('Replaced Value: ' ||
      lv_temp_txt);
END;
/

SPOOL OFF
