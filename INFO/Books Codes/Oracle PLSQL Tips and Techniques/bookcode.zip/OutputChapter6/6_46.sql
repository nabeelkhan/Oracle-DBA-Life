-- ***************************************************************************
-- File: 6_46.sql
--
-- Developed By TUSC
--
-- Disclaimer: Neither Osborne/McGraw-Hill, TUSC, nor the author warrant
--             that this source code is error-free. If any errors are
--             found in this source code, please report them to TUSC at
--             (630)960-2909 ext 1011 or trezzoj@tusc.com.
-- ***************************************************************************

SPOOL 6_46.lis

DECLARE
   lv_test_num NUMBER;
   lv_test_txt VARCHAR2(10);
   FUNCTION validate_number (p_test_txt VARCHAR2)
      RETURN NUMBER IS
         lv_return_num NUMBER;
      BEGIN
         lv_return_num := TO_NUMBER(p_test_txt);
         RETURN lv_return_num;
      EXCEPTION
         WHEN OTHERS THEN
            lv_return_num := REPLACE(TRANSLATE(p_test_txt,
               'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
               '                          '),' ');
         RETURN lv_return_num;
      END validate_number;
BEGIN
   lv_test_txt := '43546.66';
   lv_test_num := validate_number(lv_test_txt);
   DBMS_OUTPUT.PUT_LINE('Original Value: ' || lv_test_txt);
   DBMS_OUTPUT.PUT_LINE('New Value:      ' || lv_test_num);
   lv_test_txt := 'A5A46.896';
   lv_test_num := validate_number(lv_test_txt);
   DBMS_OUTPUT.PUT_LINE('Original Value: ' || lv_test_txt);
   DBMS_OUTPUT.PUT_LINE('New Value:      ' || lv_test_num);
END;
/

SPOOL OFF
