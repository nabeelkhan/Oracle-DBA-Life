/*
 * testCallPP.sql
 * Chapter 9, Oracle10g PL/SQL Programming
 * by Ron Hardman, Michael McLaughlin and Scott Urman
 *
 * This script demonstrates sequential calls to callPP.sql.
 */

@@callPP.sql
@@callPP.sql
