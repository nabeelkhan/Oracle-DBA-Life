/*
 * Lower.sql
 * Chapter 4, Oracle10g PL/SQL Programming
 * by Ron Hardman, Mike McLaughlin, Scott Urman
 *
 * This script demonstrates the LOWER function
 */

SET SERVEROUTPUT ON
BEGIN
   DBMS_OUTPUT.PUT_LINE(LOWER('CaSe Is nOt AlWAyS ImpoRtaNt'));
END;
/

