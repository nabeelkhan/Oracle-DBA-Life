select cr_requests,light_works 
from   v$cr_block_server;















