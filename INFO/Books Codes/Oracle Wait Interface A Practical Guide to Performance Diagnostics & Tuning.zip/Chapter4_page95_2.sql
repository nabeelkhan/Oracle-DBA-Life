select name
from   v$latchname
where  latch# = <cursor P2>;



