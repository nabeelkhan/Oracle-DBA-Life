alter session set events �immediate trace name ashdump, level 10�;










