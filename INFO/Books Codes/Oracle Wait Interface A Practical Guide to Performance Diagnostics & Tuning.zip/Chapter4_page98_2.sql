select object_name, subobject_name
from   dba_objects 
where  object_id = <cursor row_wait_obj#>;





