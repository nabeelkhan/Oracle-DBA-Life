select * 
from   v$latchname
where  latch# = &p2_value;







