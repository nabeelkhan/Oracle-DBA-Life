select event#, name, parameter1, parameter2, parameter3
from   v$event_name
order  by name;
