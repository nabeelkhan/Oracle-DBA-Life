alter session set events 'immediate trace name enqueues level 3';
