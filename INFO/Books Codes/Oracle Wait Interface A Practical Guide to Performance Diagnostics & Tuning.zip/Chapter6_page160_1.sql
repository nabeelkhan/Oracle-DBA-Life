alter system set events 'immediate trace name buffers level 1';
