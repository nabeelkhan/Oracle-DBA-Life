select * from v$waitstat;
