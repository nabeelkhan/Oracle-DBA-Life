select * from v$system_event where event = 'buffer busy waits';
