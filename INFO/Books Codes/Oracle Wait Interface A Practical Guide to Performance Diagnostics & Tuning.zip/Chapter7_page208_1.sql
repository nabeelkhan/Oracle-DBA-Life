select set_id, dbwr_num 
from   x$kcbwds 
order by set_id;
