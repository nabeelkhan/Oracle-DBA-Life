select indx, spin, yield, waittime 
from   x$ksllclass;
