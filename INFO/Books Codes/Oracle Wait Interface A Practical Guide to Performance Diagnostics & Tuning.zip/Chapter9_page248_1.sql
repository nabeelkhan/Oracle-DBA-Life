col snap_interval for a20
col retention for a20
select snap_interval,
       retention
from   dba_hist_wr_control;





