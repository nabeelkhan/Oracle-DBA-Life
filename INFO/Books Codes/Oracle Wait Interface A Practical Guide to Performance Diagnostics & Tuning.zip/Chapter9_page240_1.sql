select stat_name, value
from   v$osstat;

