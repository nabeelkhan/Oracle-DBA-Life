-- Prior to Oracle8i Database
select * from x$kvii where kviitag = 'kcbswc';
