begin
   dbms_workload_repository.drop_baseline('Routine Jobs', true);
end;
/









