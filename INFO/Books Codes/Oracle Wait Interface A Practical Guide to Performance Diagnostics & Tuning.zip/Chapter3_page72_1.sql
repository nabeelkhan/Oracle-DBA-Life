select cache#, type, parameter 
from   v$rowcache 
where  cache# = &P1;









