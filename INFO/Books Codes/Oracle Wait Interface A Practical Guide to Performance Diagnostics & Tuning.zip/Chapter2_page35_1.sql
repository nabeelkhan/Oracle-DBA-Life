oradebug setmypid

oradebug event 10046 trace name context forever, level 8

oradebug tracefile_name


