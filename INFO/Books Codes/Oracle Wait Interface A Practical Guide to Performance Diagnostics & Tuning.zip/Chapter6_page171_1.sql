select * from v$resource;
