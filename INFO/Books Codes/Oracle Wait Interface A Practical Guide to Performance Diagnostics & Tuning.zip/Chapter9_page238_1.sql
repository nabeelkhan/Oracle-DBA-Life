select stat_name, value
from   v$sys_time_model;
