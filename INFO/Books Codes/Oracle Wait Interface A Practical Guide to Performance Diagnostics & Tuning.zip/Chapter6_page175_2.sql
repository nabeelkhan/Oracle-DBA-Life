select chr(84) || chr(88) from dual;
