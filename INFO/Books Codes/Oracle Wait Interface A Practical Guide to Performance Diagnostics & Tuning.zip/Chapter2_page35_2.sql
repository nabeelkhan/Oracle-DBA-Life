alter session set tracefile_identifier = �MyTrace�;

