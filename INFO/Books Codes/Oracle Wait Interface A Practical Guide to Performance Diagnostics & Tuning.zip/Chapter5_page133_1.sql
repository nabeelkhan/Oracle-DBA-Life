-- Beginning in Oracle8i Database
select * from x$kvii where kviitag in ('kcbswc','kcbscw');
