REM � As a Function
select dbms_workload_repository.create_snapshot('ALL') from dual;







