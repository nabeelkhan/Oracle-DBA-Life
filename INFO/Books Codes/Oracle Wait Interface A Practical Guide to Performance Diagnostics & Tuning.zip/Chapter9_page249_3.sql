begin
  dbms_workload_repository.drop_snapshot_range (
                           low_snap_id => 1981,
                           high_snap_id => 2004 );
end;
/








