select set_id, set_latch 
from   x$kcbwds 
order by set_id;
