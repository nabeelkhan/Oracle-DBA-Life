select data_requests,fairness_down_converts 
from   v$cr_block_server;















