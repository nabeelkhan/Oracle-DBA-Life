oradebug setmypid
oradebug unlimit
oradebug dump ashdump 10
oradebug tracefile_name










