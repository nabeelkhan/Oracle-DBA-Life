select * 
from   v$event_histogram 
where  event# in (290,291);



