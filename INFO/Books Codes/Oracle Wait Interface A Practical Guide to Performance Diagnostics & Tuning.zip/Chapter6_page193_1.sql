select * 
from   dba_hist_waitstat
order by snap_id, class;
