insert into table_A
select * from table_B;
