select *
from   v$waitstat
where  count > 0;





