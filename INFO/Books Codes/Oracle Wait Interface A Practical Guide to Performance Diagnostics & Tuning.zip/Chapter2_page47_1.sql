select cpu_time 
from   v$sqlarea 
where  cpu_time between 1 and 999;




