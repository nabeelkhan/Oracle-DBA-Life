select status,count(*)
from   v$bh 
group  by status;

















