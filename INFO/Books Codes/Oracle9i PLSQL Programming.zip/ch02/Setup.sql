REM Setup.sql
REM Chapter 2, Oracle9i PL/SQL Programming by Scott Urman

REM  This file will create some database objects that are used for
REM  Chapter 2.  It requires tables.sql to already have been run.

@..\ch09\AddNewStudent
@..\ch09\AlmostFull
@..\ch09\ModeTest
@..\ch09\ClassPackage
@..\ch12\Point
@..\ch02\SimpleClass